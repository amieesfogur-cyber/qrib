# QRIB | قريب

قريب منك، قريب ليك.

أول نسخة من تطبيق QRIB مبنية بـ Flutter.  
المرحلة الحالية: واجهة Home أولية بدون Backend.

## تشغيل المشروع

```bash
flutter pub get
flutter run
```

المرحلة القادمة: Firebase + تسجيل الحساب + Qrib Now + الموقع.
